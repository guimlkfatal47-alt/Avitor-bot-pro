package br.com.aviatorbotpro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder

/**
 * Prototype scaffold. MediaProjection requires a user-approved capture session.
 * Production implementation must create a VirtualDisplay/ImageReader and stop cleanly
 * when the user revokes capture or the game closes.
 */
class CaptureService : Service() {
    private var projection: MediaProjection? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "capture")
                .setContentTitle("Aviator Bot Pro")
                .setContentText("Captura de tela autorizada pelo usuário")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("Aviator Bot Pro")
                .setContentText("Captura de tela ativa")
                .setSmallIcon(android.R.drawable.ic_menu_view).build()
        }
        startForeground(7, notification)
        val code = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("resultData", Intent::class.java)
        else @Suppress("DEPRECATION") (intent?.getParcelableExtra("resultData") as? Intent)
        if (data != null) {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            // TODO: attach VirtualDisplay + ImageReader + ML Kit OCR pipeline.
            // The capture session is intentionally not used to generate betting predictions.
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("capture", "Leitura da tela",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        projection?.stop()
        projection = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
